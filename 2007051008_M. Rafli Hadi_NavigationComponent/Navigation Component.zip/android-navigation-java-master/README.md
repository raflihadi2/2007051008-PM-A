# android-navigation-java
This project provides a working example of the Navigation Codelab (Kotlin) in Java.  
Kotlin: https://github.com/googlecodelabs/android-navigation
